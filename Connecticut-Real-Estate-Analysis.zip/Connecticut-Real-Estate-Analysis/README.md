# Connecticut-Real-Estate-Analysis
Connecticut Real Estate Analysis by using elements of semantic web
